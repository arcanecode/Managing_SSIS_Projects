﻿CREATE SEQUENCE [Sequences].[PaymentMethodID]
    AS INT
    START WITH 5
    INCREMENT BY 1;
