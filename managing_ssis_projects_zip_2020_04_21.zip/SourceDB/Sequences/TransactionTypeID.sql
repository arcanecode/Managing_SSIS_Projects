﻿CREATE SEQUENCE [Sequences].[TransactionTypeID]
    AS INT
    START WITH 15
    INCREMENT BY 1;
