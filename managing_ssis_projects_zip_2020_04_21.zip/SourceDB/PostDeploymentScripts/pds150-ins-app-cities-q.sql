﻿PRINT 'Inserting Application.Cities Q'
GO

-- Everything here was moved to pds150-ins-app-cities

