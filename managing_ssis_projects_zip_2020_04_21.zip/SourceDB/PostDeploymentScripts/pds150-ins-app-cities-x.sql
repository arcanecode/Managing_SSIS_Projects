﻿PRINT 'Inserting Application.Cities X'
GO

-- Code in here moved to pds150-ins-cities
