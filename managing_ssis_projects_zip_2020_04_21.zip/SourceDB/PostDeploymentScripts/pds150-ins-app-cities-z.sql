﻿PRINT 'Inserting Application.Cities Z'
GO

-- Code in here moved to pds150-ins-cities

