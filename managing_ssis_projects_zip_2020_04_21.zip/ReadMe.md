# Read Me

This project contains various documenation for this demo project. It is part of the course "Managing SSIS Projects, on Pluralsight. 

Please see the [Read Me](Documentation/ReadMe.md) file in the Documentation folder for more information.

## Author Information

### Author

Robert C. Cain | @ArcaneCode | arcanecode@gmail.com 

### Websites

Main Site: [http://arcanecode.me](http://arcanecode.me)

Github: [http://arcanecode.gallery](http://arcanecode.gallery)

### Copyright Notice

This document is Copyright (c) 2019, 2020 Robert C. Cain. All rights reserved.

The code samples herein is for demonstration purposes. No warranty or guarantee is implied or expressly granted.

This document, or the code samples that it accompanies, may not be reproduced in whole or in part without the express written consent of the author. Information within can be used within your own projects.
