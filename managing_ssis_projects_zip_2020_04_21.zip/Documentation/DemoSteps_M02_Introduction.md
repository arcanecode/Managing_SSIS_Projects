﻿# Module 2 - Introductionfs

The bulk of this module comes from the PowerPoint slides. You can reference them for more info on that part of the course.

The demos are very simple, we'll just open the source solution and show the various projects.

## Demo

1. Start with the Documentation project, giving a quick overview of the contents.
2. Show the source and target database projects, particularly how to deploy them.
3. Show the SSIS Project. Give a quick overview of the packages.

[Return to the DemoSteps document](DemoSteps.md)
